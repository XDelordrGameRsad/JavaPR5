package festival;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Каталог фильмов. Хранит список ссылок на объекты Movie.
 */
public class FestivalCatalog {
    private final List<Movie> movies;

    public FestivalCatalog(List<Movie> movies) {
        this.movies = new ArrayList<>(movies);
    }

    /**
     * Возвращает копию списка каталога, чтобы внешний код
     * не мог изменить исходный порядок и состав фильмов.
     */
    public List<Movie> getMovies() {
        return new ArrayList<>(movies);
    }

    public Movie findById(int id) {
        for (Movie movie : movies) {
            if (movie.getId() == id) {
                return movie;
            }
        }
        throw new IllegalArgumentException("Фильм с ID " + id + " не найден.");
    }

    /**
     * TODO01: поиск по части названия без учёта регистра.
     * Всегда возвращает новый изменяемый список.
     */
    public List<Movie> searchByTitle(String query) {
        String needle = query == null
                ? ""
                : query.strip().toLowerCase(Locale.ROOT);

        List<Movie> result = new ArrayList<>();

        for (Movie movie : movies) {
            String title = movie.getTitle().toLowerCase(Locale.ROOT);
            if (title.contains(needle)) {
                result.add(movie);
            }
        }

        return result;
    }

    /**
     * TODO02: сортировка копии по длительности, затем по ID.
     */
    public List<Movie> sortedByDuration() {
        List<Movie> result = new ArrayList<>(movies);

        Comparator<Movie> comparator =
                Comparator.comparingInt(Movie::getDuration)
                        .thenComparingInt(Movie::getId);

        result.sort(comparator);
        return result;
    }

    /**
     * TODO03 вызывается в Movie; каталог только находит фильм
     * и передаёт ему оценку.
     */
    public void addRating(int id, int rating) throws InvalidRatingException {
        findById(id).addRating(rating);
    }
}
