package festival;

import java.util.List;
import java.util.Locale;
import java.util.Scanner;

/**
 * Консольное приложение кинофестиваля.
 */
public class Main {
    private static final Scanner SCANNER = new Scanner(System.in);

    public static void main(String[] args) {
        FestivalCatalog catalog = SampleData.createCatalog();

        System.out.println("=== КИНОФЕСТИВАЛЬ: КАТАЛОГ ФИЛЬМОВ И ОЦЕНКИ ===");

        boolean running = true;
        while (running) {
            printMenu();
            Integer choice = readInt("Выберите пункт: ");
            if (choice == null) {
                System.out.println();
                continue;
            }

            switch (choice) {
                case 1 -> show(catalog.getMovies());
                case 2 -> handleSearch(catalog);
                case 3 -> show(catalog.sortedByDuration());
                case 4 -> handleRating(catalog);
                case 0 -> {
                    running = false;
                    System.out.println("Работа программы завершена.");
                }
                default -> System.out.println("Такого пункта меню нет.");
            }
            System.out.println();
        }
    }

    private static void printMenu() {
        System.out.println("1. Показать исходный каталог");
        System.out.println("2. Найти фильм по названию");
        System.out.println("3. Просмотреть фильмы по длительности");
        System.out.println("4. Добавить зрительскую оценку");
        System.out.println("0. Выход");
    }

    private static void handleSearch(FestivalCatalog catalog) {
        System.out.print("Введите название или его часть: ");
        String query = SCANNER.nextLine();

        List<Movie> result = catalog.searchByTitle(query);
        if (result.isEmpty()) {
            System.out.println("Фильмы не найдены.");
        } else {
            show(result);
        }
    }

    /**
     * TODO04: обрабатывает предметную ошибку и сообщает результат.
     */
    private static void handleRating(FestivalCatalog catalog) {
        Integer id = readInt("Введите ID фильма: ");
        if (id == null) {
            return;
        }

        Integer rating = readInt("Введите оценку от 1 до 10: ");
        if (rating == null) {
            return;
        }

        try {
            catalog.addRating(id, rating);
            System.out.println("Оценка добавлена.");
        } catch (InvalidRatingException e) {
            System.out.println("Оценка отклонена: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Ошибка: " + e.getMessage());
        }
    }

    private static void show(List<Movie> movies) {
        if (movies.isEmpty()) {
            System.out.println("Список пуст.");
            return;
        }

        for (Movie movie : movies) {
            System.out.println(movie);
        }
    }

    /**
     * Безопасное чтение целого числа: при ошибке возвращает пользователя к меню.
     */
    private static Integer readInt(String prompt) {
        System.out.print(prompt);
        String input = SCANNER.nextLine().strip();

        try {
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            System.out.println("Ошибка: необходимо ввести целое число. Возврат в меню.");
            return null;
        }
    }
}
