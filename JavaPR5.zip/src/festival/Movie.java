package festival;

import java.util.ArrayList;
import java.util.List;

/**
 * Модель одного фильма кинофестиваля.
 */
public class Movie {
    private final int id;
    private final String title;
    private final int duration;
    private final List<Integer> ratings;

    public Movie(int id, String title, int duration, List<Integer> ratings) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID должен быть положительным.");
        }
        if (title == null || title.isBlank()) {
            throw new IllegalArgumentException("Название фильма не может быть пустым.");
        }
        if (duration <= 0) {
            throw new IllegalArgumentException("Длительность должна быть положительной.");
        }

        this.id = id;
        this.title = title;
        this.duration = duration;
        this.ratings = new ArrayList<>();

        if (ratings != null) {
            for (int rating : ratings) {
                if (rating < 1 || rating > 10) {
                    throw new IllegalArgumentException(
                            "Начальная оценка должна быть от 1 до 10: " + rating);
                }
                this.ratings.add(rating);
            }
        }
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public int getDuration() {
        return duration;
    }

    /**
     * Возвращает неизменяемую копию оценок.
     */
    public List<Integer> getRatings() {
        return List.copyOf(ratings);
    }

    public boolean hasRatings() {
        return !ratings.isEmpty();
    }

    public double averageRating() {
        if (ratings.isEmpty()) {
            return 0.0;
        }

        int sum = 0;
        for (int rating : ratings) {
            sum += rating;
        }
        return (double) sum / ratings.size();
    }

    /**
     * Добавляет оценку только после проверки допустимого диапазона.
     */
    public void addRating(int rating) throws InvalidRatingException {
        if (rating < 1 || rating > 10) {
            throw new InvalidRatingException(rating);
        }
        ratings.add(rating);
    }

    @Override
    public String toString() {
        String average = hasRatings()
                ? String.format(java.util.Locale.ROOT, "%.2f", averageRating())
                : "нет оценок";

        return String.format(
                java.util.Locale.ROOT,
                "ID: %d | %s | %d мин. | Оценки: %s | Среднее: %s",
                id, title, duration, ratings.isEmpty() ? "нет" : ratings, average
        );
    }
}
