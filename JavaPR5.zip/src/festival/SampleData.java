package festival;

import java.util.ArrayList;
import java.util.List;

/**
 * Создание исходного набора фильмов.
 */
public final class SampleData {
    private SampleData() {
    }

    public static FestivalCatalog createCatalog() {
        List<Movie> movies = new ArrayList<>();

        // Исходный порядок ID: 3, 1, 6, 2, 5, 4.
        movies.add(new Movie(3, "Тихий берег", 100, List.of(7, 7)));
        movies.add(new Movie(1, "Северный свет", 90, List.of(8, 8)));
        movies.add(new Movie(6, "Письмо домой", 95, List.of()));
        movies.add(new Movie(2, "Последний трамвай", 110, List.of(10, 2)));
        movies.add(new Movie(5, "Летний дождь", 90, List.of(9, 3)));
        movies.add(new Movie(4, "Город на рассвете", 120, List.of(8, 6)));

        return new FestivalCatalog(movies);
    }
}
